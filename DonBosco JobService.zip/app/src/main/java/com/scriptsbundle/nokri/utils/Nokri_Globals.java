package com.scriptsbundle.nokri.utils;

/**
 * Created by Glixen Technologies on 24/01/2018.
 */

public class Nokri_Globals {

    public  static String EDIT_MESSAGE;
    public static String EMPTY_FIELDS_PLACEHOLDER = "All Fields Are Mandatory";
    public static  String NO_URL_FOUND = "No Url Found";
    public static  String COMMENT_REQUIRED_TEXT = "Please write a comment first";
    public static  String REQUIRED_REPY_TEXT = "Please write a reply first";
    public static  String REQUIRED_Employee_Login_TEXT = "Please login as employer";

    public static  String APP_NOT_FOUNT = "No App Found To Open This File";
    public static  String EXIT_TEXT = "Exit?";
    public static String INVALID_EMAIL = "Email Format Not Valid";
    public static String TERMS_AND_SERVICES = "You Must Agree With Our Term And Services";
    public static String ON_BACK_EXIT_TEXT = "Please click BACK again to exit";
    public static String SELECT_VALID_SKILL = "Please Select A Valid Skill From The Droprown";
    public static  String SELECT_SKILL = "Please Select At Least One Skill";
    public static  String Continue_buy_Package = "Continue Buy Package";
    public static String LOGIN_FIRST = "";
    public static String NEXT_STEP = "";
    public static String APP_NOT_INSTALLED = "This app is not installed";
    public static String INVALID_URL = "invalid url";
    public static boolean IS_RTL_ENABLED = false;
    public static  String AD_ID = "";
    public static  String INTERTIAL_ID = "";
    public static boolean  IS_INTERTIAL_ENABLED = false;
    public static boolean IS_BANNER_EBABLED = false;
    public static  long AD_INITIAL_TIME = 10;
    public static  long AD_DISPLAY_TIME  = 60;
    public static boolean SHOW_AD_TOP = false;
    public static boolean SHOW_AD = false;
    public static boolean SHOULD_HOW_FIREBASE_NOTIFICATION = false;
    public static String PLEASE_WAIT_TEXT = "";
    public static String JOB_SEARCH_PLACEHOLER = "";
    public static String tagline = "Over 1 millions jobs resume pools";


}





