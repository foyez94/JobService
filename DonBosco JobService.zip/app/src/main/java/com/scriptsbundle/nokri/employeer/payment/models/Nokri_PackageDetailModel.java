package com.scriptsbundle.nokri.employeer.payment.models;

public class Nokri_PackageDetailModel {
    private String title;
    private String packageDetail;
    private String srNum;

    public String getSrNum() {
        return srNum;
    }

    public void setSrNum(String srNum) {
        this.srNum = srNum;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getPackageDetail() {
        return packageDetail;
    }

    public void setPackageDetail(String packageDetail) {
        this.packageDetail = packageDetail;
    }
}
